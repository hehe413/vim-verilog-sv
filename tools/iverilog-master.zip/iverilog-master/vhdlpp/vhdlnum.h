#ifndef IVL_vhdlnum_H
#define IVL_vhdlnum_H

#include "config.h"

#warning vhdlnum

class vhdlnum {
    public:
        vhdlnum(char* text) {}
};

#endif /* IVL_vhdlnum_H */
